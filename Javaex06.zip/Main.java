public class Main {
    public static void main(String[] args) {

        Student student = new Student("Jamshid Kashani ", "12345", "Mathematics", "University A");
        Professor professor = new Professor("Dr. Winstein", "Computer Networks", "Engineering", 3);


        System.out.println("Is student an instance of Human? " + (student instanceof Human));
        System.out.println("Is professor an instance of Human? " + (professor instanceof Human));


        Human human1 = new Student("Évariste Galois", "67890", "Mathematics", "University B");
        human1.sayMyName();

        Human human2 = new Professor("Dr. Hao", "Artificial Intelligence", "Computer Science", 2);
        human2.sayMyName();


    }
}