public class Student extends Human {
    private String studentNumber;
    private String majorName;
    private String universityName;

    public Student(String fullName, String studentNumber, String majorName, String universityName) {
        setFullName(fullName);
        this.studentNumber = studentNumber;
        this.majorName = majorName;
        this.universityName = universityName;
    }
    public String getStudentNumber() {
        return studentNumber;
    }
    public void setStudentNumber(String studentNumber) {
        this.studentNumber = studentNumber;
    }
    public String getMajorName() {
        return majorName;
    }
    public void setMajorName(String majorName) {
        this.majorName = majorName;
    }
    public String getUniversityName() {
        return universityName;
    }
    public void setUniversityName(String universityName) {
        this.universityName = universityName;
    }
    @Override
    public void sayMyName() {
        System.out.println("My name is: " + getFullName());
    }
}